function Aluno(props){
    return (
    <div>
        <h1> Olá, eu sou {props.nome} um componente Aluno do curso de ADS!!</h1>
        <p> Eu tenho {props.idade} anos </p>
    </div>
    )
};

export default Aluno;