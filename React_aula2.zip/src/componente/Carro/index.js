function Carro (props) {
    return(
        <>
            {/*Dados que vem de um objeto*/}
            <h2> Meu carro favorito é {props.carroinfo.nome} da marca {props.carroinfo.nome}</h2>

            <p> Mas o carro tem que ser dos anos {props.carroanos [0]}, {props.carroanos [1]}, {props.carroanos [2]}</p>
        </>
    );
};

export default Carro;