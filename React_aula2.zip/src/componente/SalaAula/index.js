import Aluno from   '../Aluno/index';

function SalaAula () {
    //Estrutura de dados dos alunos 
    const objAlunos = [
        {nome:'Marco' , idade: 21},
        {nome:'Joao' , idade: 23},
        {nome:'Silva' , idade: 22},
    ];

    return(
        <>
            {/*Usando o componente Aluno dentro de Sala*/}
            <Aluno nome = {objAlunos[0].nome} idade = {objAlunos[0].idade } />

            <Aluno nome = {objAlunos[1].nome} idade = {objAlunos[1].idade } />

            <Aluno nome = {objAlunos[2].nome} idade = {objAlunos[2].idade } />
        </>

    );
};

export default SalaAula;