import './App.css';
import Aluno from './componente/Aluno/index.js'
import Carro from './componente/Carro/index.js'
import SalaAula from './componente/SalaAula/index.js';

//Função fora do componente App() do React
function apresentarMensagem() {
  alert ("Mensagem função externa executada ao clicar no botão!!")
}

function App() {
  const classVar = 'App'

//Função dentro do componente App() do react
  const funcapresentarMensagem =() =>{
    alert ("Mensagem função INTERNA executada ao clicar no botão!!");
  };

//Criar um objeto de configuração de estilo CSS (CSS-Inline no React)
const estiloBotao = {
  color:'white',
  backgroundColor:'black',
  fontSize:'20px'
};

//Utilizando condicionais para desenhar conteúdos 
let usuarioConectado = false;
let mensagemUsuario = 'Usuário ainda não conectou no REACT!!';
if (usuarioConectado){
  mensagemUsuario = 'Usuário CONECTADO no REACT!!';
}

// Retorno de dados de Carro Favorito, hipotético do DB
const arrCarroAnos = [1996, 1967, 1968];
const objCarro = {nome:'Mustang', marca: 'Ford'};


  return (
    <div className="App-header">

      {/*Usando o componente Aluno dentro do App.js*/}
      <Aluno nome = 'Julyana' idade={21}/>
      <Aluno nome = 'João' idade={18}/>
      <Aluno nome = 'Silva' idade={32}/>

      <Carro carroinfo = {objCarro} carroanos = {arrCarroAnos}/>

      <h1 className = 'App'> Configurando meu aplicativo React com uma classe no h1 </h1>

      {/* Carregando um nome de classe, através de variável JavaScript*/}
      <h1 className= {classVar}> Configurando meu aplicativo React com uma classe no h1 </h1>

      {/*Configurando um botão para mostrar uma mensagem na tela */}
      <button  style = {estiloBotao} onClick={apresentarMensagem}> Clique aqui para mostrar uma mensagem </button>

      {/*Configurando um botão para mostrar uma mensagem na tela */}
      <button onClick={funcapresentarMensagem} disabled = {false}> Clique aqui para mostrar uma mensagem </button>

      {/*Apresentar o texto condicional do IF*/}
      <h2>{mensagemUsuario }</h2>

      {/*Apresentar o texto condicional através do Operador Ternário*/}
      <h2>{usuarioConectado? 'Usuário CONECTADO no REACT!! (ternário)' : 'Usuário ainda não conectou no REACT!! (ternário)' }</h2>

      {/*Apresentar o texto condicional através do Operador &&*/}
      { usuarioConectado && <h2> Usuário CONECTADO no REACT com &&!! </h2>}

      {/*Gerar todos os alunos usando o componente SalaAula*/}
      <SalaAula/>

      {/*Componente alunos só são desenhados se tiver usuário conectado*/}
      {usuarioConectado && <SalaAula/>}

    </div>
  );
}

export default App;
